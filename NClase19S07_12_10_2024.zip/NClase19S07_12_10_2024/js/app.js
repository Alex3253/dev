/*
--------------------------DECLARACION DE VARIABLES-----------------------------------
--------------------------------------------------------------------------------------------------
*/

//-------------------------Contenedor HEADER --------------------------------------------
//---> (Contenedor principal - tabla y boton)
const carrito = document.querySelector('#carrito');
//---> (Tabla del carrito-<table> ----- > Cuerpo-<tbody>)
const contenedorCarrito = document.querySelector('#lista-carrito tbody');
//---> (Hipervinculo fuera de la boton-<a>)
const vaciarCarritoBtn = document.querySelector('#vaciar-carrito')
//-------------------------Contenedor CONTAINER ----------------------------------------
const listaCursos = document.querySelector('#lista-cursos')
//-------------Definir un arreglo para almacenar los cursos seleccionados----------
let articulosCarrito = [];

/*
-----------------------ENTRADA DE DATOS-------------------------------------------------
-------------------------------------------------------------------------------------------------
*/

listaCursos.addEventListener('click',agregarCurso)

function agregarCurso(e){
    if(e.target.classList.contains('agregar-carrito')){
        e.preventDefault()
        const cursoSeleccionado = e.target.parentElement.parentElement
        leerDatosCurso(cursoSeleccionado)
    }
}

function leerDatosCurso(cursoSeleccionado){
    const infoCurso = {
        imagen: cursoSeleccionado.querySelector('img').src,
        titulo: cursoSeleccionado.querySelector('h4').textContent,
        precio: cursoSeleccionado.querySelector('span').textContent,
        id: cursoSeleccionado.querySelector('a').getAttribute('data-id'),
        cantidad: 1
    }
    articulosCarrito = [...articulosCarrito,infoCurso]
    //Invoca al carrito de compras
    carritoHTML();
}

function carritoHTML(){
    //iterar el arrglos basico por elemento
    articulosCarrito.forEach((curso)=>{
        const row = document.createElement('tr')
        row.innerHTML = `
        <td>
            <img src="${curso.imagen}" width="100px">
        </td>
        <td>${curso.titulo}</td>
        <td>${curso.precio}</td>
        <td>${curso.cantidad}</td>
    `
    contenedorCarrito.appendChild(row)
    })
    console.log(articulosCarrito)
    
}





